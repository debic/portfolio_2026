import Button from "../Button/Button";
import "./AboutSection.css";

function AboutSection(): JSX.Element {
  return (
    <section className="about-section" id="about">
      {/* Bottom — photo left, bio + button right */}
      <div className="about-section__bottom">
        <div className="about-section__photo-wrap">
          <img
            src={`${import.meta.env.BASE_URL}debi2.jpg`}
            alt="Debi Perez"
            className="about-section__photo"
          />
        </div>
        <div className="about-section__bio-wrap">
          {/* Title — centered */}
          <p className="about-section__label">About me</p>
          <h2 className="about-section__title">
            I Help People Find Their Identity Through a Website.
          </h2>
          <p className="about-section__bio">
            I started in UX/UI design, obsessing over how things look and feel.
            Then I got curious about how they're actually built — and never
            looked back. Today I bridge both worlds, designing and developing
            experiences that feel intentional from the first pixel to the last
            line of code.
          </p>
        </div>
      </div>
    </section>
  );
}

export default AboutSection;
